/* Return jQuery (for requirejs) */
define( [], function () {
	'use strict';
	return jQuery;
});