/* Return Underscore (for requirejs) */
define( [], function () {
	'use strict';
	return _;
});