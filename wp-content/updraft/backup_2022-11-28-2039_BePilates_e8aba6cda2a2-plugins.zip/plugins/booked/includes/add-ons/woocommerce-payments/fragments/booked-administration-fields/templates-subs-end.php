<?php if ( $look_for_subs==='paid-service' ): ?>
		</ul>
		<button class="cfButton button" data-type="single-paid-service">+ <?php _e('Product', 'booked'); ?></button>
		<span class="cf-delete"><i class="fa-solid fa-trash-can"></i></span>
	</li>
<?php endif ?>
